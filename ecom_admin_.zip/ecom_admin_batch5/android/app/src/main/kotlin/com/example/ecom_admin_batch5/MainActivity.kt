package com.example.ecom_admin_batch5

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
